package com.itrosys.admissions_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmissionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
